export const publicKey = `-----BEGIN RSA PUBLIC KEY-----
        MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAt4pOmBaGkaZvjwIjIKIL
        MFgH7AP8Rm9pThxeJ4C5GjwO0eh4Gyfx16V/l9nZD9PJ1eS+fyGq2qQw8rxo6yAH
        pq+TBM5Iza85xsR6Utqtto2YLSaqsMKn5X8rJ7xtZ+kVo2kgccLrHbrp63LybwDL
        T9Wl6K9x3PbIqNeXwoIOuFc5I1UXP7LpG/oxfu43kgID7H2KmPr7tN2Bri2UHiWD
        KWpiDngRXiiiq9E08sgZJSZKi4IxZwFUBp0MSdAFKn7nK/dX57Xpf4zJPQPOZ2Pm
        4CcZ/1ETi01cguM9dxhd/g2CUA3NdUO9q95jtHCruilVEXLyyZMJMxBRV+J4In/v
        dQIDAQAB
        -----END RSA PUBLIC KEY-----
        `;

export const privateKey = ``;